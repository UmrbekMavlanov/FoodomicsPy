"""
Chemometric model plots for FoodomicsPy.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from matplotlib.ticker import MaxNLocator


def plot_pls(
    result,
    figsize=(15, 4.7),
    point_size=55,
    point_alpha=0.85,
    show_calibration=False,
    show_regression_line=False,
    show_sample_labels=False,
    label_residual_threshold=None,
    title=None,
    save_path=None,
    dpi=600,
):
    """
    Create publication-ready diagnostic plots for a PLS regression model.

    The figure contains three panels:

        A. RMSECV versus number of PLS components
        B. Measured versus cross-validated predicted values
        C. Cross-validated residuals versus predicted values

    Parameters
    ----------
    result : dict
        Result dictionary returned by perform_pls().

        The dictionary must contain:

            "component_results"
            "n_components"
            "y_measured"
            "y_cv_predicted"
            "residuals_cv"
            "rmsecv"
            "r2cv"

        Optional entries used when available:

            "y_calibration_predicted"
            "rmsec"
            "r2c"
            "maecv"
            "bias_cv"
            "prediction_slope"
            "prediction_intercept"
            "sample_names"
            "y_name"

    figsize : tuple, default=(15, 4.7)
        Overall figure size.

    point_size : float, default=55
        Scatter-point size.

    point_alpha : float, default=0.85
        Scatter-point transparency.

    show_calibration : bool, default=False
        Show calibration predictions in the measured-versus-predicted
        panel in addition to cross-validation predictions.

        Cross-validation predictions remain the primary result.

    show_regression_line : bool, default=False
        Add a fitted regression line to the measured-versus-predicted
        panel.

        The identity line is always displayed.

    show_sample_labels : bool, default=False
        Label all observations using result["sample_names"].

        For large datasets, it is usually better to leave this False.

    label_residual_threshold : float or None, default=None
        Label only samples whose absolute cross-validation residual is
        greater than or equal to this threshold.

        For example:

            label_residual_threshold=2.5

    title : str or None, default=None
        Optional overall figure title.

    save_path : str, pathlib.Path, or None, default=None
        Optional output path.

        Supported extensions include:

            .png
            .svg
            .pdf
            .tiff

        Example:

            save_path="figures/pls_diagnostics.svg"

    dpi : int, default=600
        Resolution used for raster output.

    Returns
    -------
    fig : matplotlib.figure.Figure
        Matplotlib figure.

    axes : numpy.ndarray of matplotlib.axes.Axes
        Array containing the three axes.

    Examples
    --------
    >>> fig, axes = f.plotting.plot_pls(result)

    >>> fig, axes = f.plotting.plot_pls(
    ...     result,
    ...     title="PLS model for moisture prediction",
    ...     save_path="PLS_moisture.svg",
    ... )

    >>> fig, axes = f.plotting.plot_pls(
    ...     result,
    ...     label_residual_threshold=2.5,
    ... )
    """

    # ==================================================================
    # 1. VALIDATE INPUT
    # ==================================================================
    if not isinstance(result, dict):
        raise TypeError(
            "'result' must be the dictionary returned by perform_pls()."
        )

    required_keys = {
        "component_results",
        "n_components",
        "y_measured",
        "y_cv_predicted",
        "residuals_cv",
        "rmsecv",
        "r2cv",
    }

    missing_keys = required_keys.difference(result)

    if missing_keys:
        raise KeyError(
            "The PLS result is missing the following required entries: "
            f"{sorted(missing_keys)}"
        )

    component_results = result["component_results"].copy()

    required_component_columns = {
        "n_components",
        "rmsecv",
    }

    missing_columns = required_component_columns.difference(
        component_results.columns
    )

    if missing_columns:
        raise KeyError(
            "result['component_results'] is missing the following "
            f"columns: {sorted(missing_columns)}"
        )

    y_measured = np.asarray(
        result["y_measured"],
        dtype=float,
    ).reshape(-1)

    y_cv_predicted = np.asarray(
        result["y_cv_predicted"],
        dtype=float,
    ).reshape(-1)

    residuals_cv = np.asarray(
        result["residuals_cv"],
        dtype=float,
    ).reshape(-1)

    if not (
        len(y_measured)
        == len(y_cv_predicted)
        == len(residuals_cv)
    ):
        raise ValueError(
            "Measured values, CV predictions, and CV residuals must "
            "have the same length."
        )

    n_samples = len(y_measured)

    sample_names = result.get(
        "sample_names",
        np.arange(1, n_samples + 1),
    )

    sample_names = np.asarray(sample_names).reshape(-1)

    if len(sample_names) != n_samples:
        sample_names = np.arange(1, n_samples + 1)

    best_n_components = int(result["n_components"])
    rmsecv = float(result["rmsecv"])
    r2cv = float(result["r2cv"])

    maecv = result.get("maecv")
    bias_cv = result.get("bias_cv")

    y_name = result.get("y_name")

    if y_name is None:
        y_name = "Response"

    # ==================================================================
    # 2. COLORS
    # ==================================================================
    color_primary = "#246B73"
    color_secondary = "#D58A35"
    color_dark = "#222222"
    color_grey = "#777777"
    color_light_grey = "#D9D9D9"
    color_grid = "#E8E8E8"
    color_residual = "#A34545"
    color_calibration = "#9A9A9A"

    # ==================================================================
    # 3. MATPLOTLIB SETTINGS
    # ==================================================================
    plot_settings = {
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans",
        ],
        "font.size": 10,
        "axes.labelsize": 11,
        "axes.titlesize": 12,
        "axes.titleweight": "bold",
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "axes.linewidth": 0.9,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }

    with plt.rc_context(plot_settings):

        # ==============================================================
        # 4. CREATE FIGURE
        # ==============================================================
        fig, axes = plt.subplots(
            nrows=1,
            ncols=3,
            figsize=figsize,
            constrained_layout=False,
        )

        ax_components = axes[0]
        ax_predictions = axes[1]
        ax_residuals = axes[2]

        # ==============================================================
        # 5. PANEL A — COMPONENT SELECTION
        # ==============================================================
        n_components = component_results[
            "n_components"
        ].to_numpy()

        rmsecv_values = component_results[
            "rmsecv"
        ].to_numpy()

        ax_components.plot(
            n_components,
            rmsecv_values,
            color=color_primary,
            linewidth=2.0,
            marker="o",
            markersize=5.5,
            markerfacecolor="white",
            markeredgecolor=color_primary,
            markeredgewidth=1.4,
            zorder=3,
        )

        selected_row = component_results.loc[
            component_results["n_components"]
            == best_n_components
        ]

        if selected_row.empty:
            best_rmsecv = rmsecv
        else:
            best_rmsecv = float(
                selected_row["rmsecv"].iloc[0]
            )

        ax_components.scatter(
            best_n_components,
            best_rmsecv,
            s=105,
            color=color_secondary,
            edgecolor="white",
            linewidth=1.5,
            zorder=5,
            label=(
                f"Selected: {best_n_components} components"
            ),
        )

        ax_components.axvline(
            best_n_components,
            color=color_secondary,
            linewidth=1.0,
            linestyle=(0, (4, 3)),
            alpha=0.8,
            zorder=1,
        )

        ax_components.annotate(
            (
                f"{best_n_components} components\n"
                f"RMSECV = {best_rmsecv:.3f}"
            ),
            xy=(best_n_components, best_rmsecv),
            xytext=(10, 18),
            textcoords="offset points",
            fontsize=9,
            color=color_dark,
            ha="left",
            va="bottom",
            bbox={
                "boxstyle": "round,pad=0.35",
                "facecolor": "white",
                "edgecolor": color_light_grey,
                "linewidth": 0.8,
                "alpha": 0.95,
            },
            arrowprops={
                "arrowstyle": "-",
                "color": color_grey,
                "linewidth": 0.8,
            },
        )

        ax_components.set_xlabel(
            "Number of PLS components"
        )

        ax_components.set_ylabel("RMSECV")

        ax_components.set_title(
            "Model complexity",
            loc="left",
            pad=12,
        )

        ax_components.xaxis.set_major_locator(
            MaxNLocator(integer=True)
        )

        # ==============================================================
        # 6. PANEL B — MEASURED VS PREDICTED
        # ==============================================================
        combined_values = np.concatenate(
            [y_measured, y_cv_predicted]
        )

        if show_calibration:
            if "y_calibration_predicted" not in result:
                raise KeyError(
                    "show_calibration=True requires "
                    "result['y_calibration_predicted']."
                )

            y_calibration_predicted = np.asarray(
                result["y_calibration_predicted"],
                dtype=float,
            ).reshape(-1)

            combined_values = np.concatenate(
                [
                    combined_values,
                    y_calibration_predicted,
                ]
            )

            ax_predictions.scatter(
                y_measured,
                y_calibration_predicted,
                s=point_size * 0.8,
                color=color_calibration,
                edgecolor="white",
                linewidth=0.7,
                alpha=0.50,
                label="Calibration",
                zorder=2,
            )

        value_min = np.nanmin(combined_values)
        value_max = np.nanmax(combined_values)

        value_range = value_max - value_min

        if np.isclose(value_range, 0):
            value_range = 1.0

        padding = value_range * 0.07

        plot_min = value_min - padding
        plot_max = value_max + padding

        ax_predictions.plot(
            [plot_min, plot_max],
            [plot_min, plot_max],
            color=color_dark,
            linewidth=1.2,
            linestyle=(0, (5, 4)),
            label="Identity line",
            zorder=1,
        )

        ax_predictions.scatter(
            y_measured,
            y_cv_predicted,
            s=point_size,
            color=color_primary,
            edgecolor="white",
            linewidth=0.9,
            alpha=point_alpha,
            label="Cross-validation",
            zorder=3,
        )

        if show_regression_line:
            slope, intercept = np.polyfit(
                y_measured,
                y_cv_predicted,
                deg=1,
            )

            regression_x = np.array(
                [plot_min, plot_max]
            )

            regression_y = (
                slope * regression_x + intercept
            )

            ax_predictions.plot(
                regression_x,
                regression_y,
                color=color_secondary,
                linewidth=1.8,
                label="Fitted line",
                zorder=2,
            )

        metric_lines = [
            rf"$R^2_{{CV}}$ = {r2cv:.3f}",
            f"RMSECV = {rmsecv:.3f}",
        ]

        if maecv is not None:
            metric_lines.append(
                f"MAECV = {float(maecv):.3f}"
            )

        if bias_cv is not None:
            metric_lines.append(
                f"Bias = {float(bias_cv):.3f}"
            )

        ax_predictions.text(
            0.05,
            0.95,
            "\n".join(metric_lines),
            transform=ax_predictions.transAxes,
            ha="left",
            va="top",
            fontsize=9.5,
            linespacing=1.35,
            bbox={
                "boxstyle": "round,pad=0.45",
                "facecolor": "white",
                "edgecolor": "white",
                "linewidth": 0.8,
                "alpha": 0.95,
            },
            zorder=10,
        )

        ax_predictions.set_xlim(plot_min, plot_max)
        ax_predictions.set_ylim(plot_min, plot_max)

        ax_predictions.set_aspect(
            "equal",
            adjustable="box",
        )

        ax_predictions.set_xlabel(
            f"Measured {y_name}"
        )

        ax_predictions.set_ylabel(
            f"Cross-validated predicted {y_name}"
        )

        ax_predictions.set_title(
            "Prediction performance",
            loc="left",
            pad=12,
        )

        # ==============================================================
        # 7. PANEL C — RESIDUALS
        # ==============================================================
        ax_residuals.axhline(
            0,
            color=color_dark,
            linewidth=1.1,
            linestyle=(0, (5, 4)),
            zorder=1,
        )

        ax_residuals.scatter(
            y_cv_predicted,
            residuals_cv,
            s=point_size,
            color=color_residual,
            edgecolor="white",
            linewidth=0.9,
            alpha=point_alpha,
            zorder=3,
        )

        residual_sd = np.std(
            residuals_cv,
            ddof=1,
        )

        if np.isfinite(residual_sd) and residual_sd > 0:
            ax_residuals.axhline(
                2 * residual_sd,
                color=color_grey,
                linewidth=0.9,
                linestyle=(0, (2, 3)),
                alpha=0.75,
                zorder=1,
            )

            ax_residuals.axhline(
                -2 * residual_sd,
                color=color_grey,
                linewidth=0.9,
                linestyle=(0, (2, 3)),
                alpha=0.75,
                zorder=1,
            )

            ax_residuals.text(
                0.98,
                2 * residual_sd,
                "+2 SD ",
                transform=ax_residuals.get_yaxis_transform(),
                ha="right",
                va="bottom",
                fontsize=8,
                color=color_grey,
            )

            ax_residuals.text(
                0.98,
                -2 * residual_sd,
                "−2 SD ",
                transform=ax_residuals.get_yaxis_transform(),
                ha="right",
                va="top",
                fontsize=8,
                color=color_grey,
            )

        ax_residuals.set_xlabel(
            f"Cross-validated predicted {y_name}"
        )

        ax_residuals.set_ylabel(
            "Residual (measured − predicted)"
        )

        ax_residuals.set_title(
            "Residual diagnostics",
            loc="left",
            pad=12,
        )

        # ==============================================================
        # 8. SAMPLE LABELS
        # ==============================================================
        if show_sample_labels:
            label_mask = np.ones(
                n_samples,
                dtype=bool,
            )

        elif label_residual_threshold is not None:
            if label_residual_threshold < 0:
                raise ValueError(
                    "'label_residual_threshold' must be "
                    "greater than or equal to zero."
                )

            label_mask = (
                np.abs(residuals_cv)
                >= label_residual_threshold
            )

        else:
            label_mask = np.zeros(
                n_samples,
                dtype=bool,
            )

        for index in np.where(label_mask)[0]:
            label = str(sample_names[index])

            ax_predictions.annotate(
                label,
                (
                    y_measured[index],
                    y_cv_predicted[index],
                ),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=7.5,
                color=color_dark,
                alpha=0.9,
            )

            ax_residuals.annotate(
                label,
                (
                    y_cv_predicted[index],
                    residuals_cv[index],
                ),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=7.5,
                color=color_dark,
                alpha=0.9,
            )

        # ==============================================================
        # 9. COMMON STYLE
        # ==============================================================
        panel_labels = ["A", "B", "C"]

        for ax, panel_label in zip(
            axes,
            panel_labels,
        ):
            ax.text(
                -0.15,
                1.08,
                panel_label,
                transform=ax.transAxes,
                fontsize=14,
                fontweight="bold",
                ha="left",
                va="top",
                color=color_dark,
            )

            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

            ax.spines["left"].set_color(
                color_dark
            )

            ax.spines["bottom"].set_color(
                color_dark
            )

            ax.tick_params(
                axis="both",
                direction="out",
                length=4,
                width=0.8,
                color=color_dark,
            )

            ax.grid(
                True,
                axis="both",
                color=color_grid,
                linewidth=0.7,
                alpha=0.65,
                zorder=0,
            )

            ax.set_axisbelow(True)

        # ==============================================================
        # 10. OPTIONAL OVERALL TITLE
        # ==============================================================
        if title is not None:
            fig.suptitle(
                title,
                fontsize=15,
                fontweight="bold",
                x=0.06,
                ha="left",
                y=1.02,
            )

        # ==============================================================
        # 11. SPACING
        # ==============================================================
        fig.subplots_adjust(
            left=0.065,
            right=0.985,
            bottom=0.17,
            top=0.86 if title is None else 0.81,
            wspace=0.35,
        )

        # ==============================================================
        # 12. SAVE
        # ==============================================================
        if save_path is not None:
            save_path = Path(save_path)

            save_path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            if save_path.suffix == "":
                save_path = save_path.with_suffix(
                    ".png"
                )

            fig.savefig(
                save_path,
                dpi=dpi,
                bbox_inches="tight",
                facecolor="white",
            )

    return fig, axes
